Installation and documentation
==============================

Please see the documentation at `http://www.tipfy.org <http://www.tipfy.org>`_.
